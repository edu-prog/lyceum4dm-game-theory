mkdir -p bundled/node_modules/eduprog-theme/styles
cp -r node_modules/eduprog-theme/styles/* bundled/node_modules/eduprog-theme/styles/